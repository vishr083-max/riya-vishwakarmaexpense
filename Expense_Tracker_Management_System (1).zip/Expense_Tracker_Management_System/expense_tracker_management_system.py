import csv
import os
from datetime import datetime

FILE_NAME = "expenses.csv"
FIELDS = ["expense_id", "date", "category", "description", "amount"]


def load_expenses():
    """Load saved expenses from CSV. Return an empty list if no file exists."""
    expenses = []
    if not os.path.exists(FILE_NAME):
        return expenses

    try:
        with open(FILE_NAME, "r", newline="", encoding="utf-8") as file:
            reader = csv.DictReader(file)
            for row in reader:
                try:
                    expenses.append({
                        "expense_id": int(row["expense_id"]),
                        "date": row["date"],
                        "category": row["category"],
                        "description": row["description"],
                        "amount": float(row["amount"]),
                    })
                except (ValueError, KeyError, TypeError):
                    # Ignore any malformed row instead of crashing.
                    continue
    except OSError as error:
        print(f"Warning: Could not read saved expenses: {error}")
    return expenses


def save_expenses(expenses):
    """Save all expenses to CSV."""
    try:
        with open(FILE_NAME, "w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=FIELDS)
            writer.writeheader()
            for expense in expenses:
                row = expense.copy()
                row["amount"] = f'{expense["amount"]:.2f}'
                writer.writerow(row)
        return True
    except OSError as error:
        print(f"Error: Could not save expenses: {error}")
        return False


def next_id(expenses):
    return max((expense["expense_id"] for expense in expenses), default=0) + 1


def read_date(prompt="Enter date (YYYY-MM-DD) or press Enter for today: "):
    while True:
        value = input(prompt).strip()
        if not value:
            return datetime.today().strftime("%Y-%m-%d")
        try:
            return datetime.strptime(value, "%Y-%m-%d").strftime("%Y-%m-%d")
        except ValueError:
            print("Invalid date. Please use YYYY-MM-DD, for example 2026-10-25.")


def read_amount(prompt="Enter amount (₹): "):
    while True:
        value = input(prompt).strip().replace(",", "")
        try:
            amount = float(value)
            if amount <= 0:
                print("Amount must be greater than zero.")
                continue
            return round(amount, 2)
        except ValueError:
            print("Please enter a valid number, for example 250 or 99.50.")


def find_by_id(expenses, expense_id):
    for expense in expenses:
        if expense["expense_id"] == expense_id:
            return expense
    return None


def print_expense_table(expenses):
    if not expenses:
        print("\nNo expenses found.")
        return

    print("\n" + "-" * 88)
    print(f'{"ID":<5} {"Date":<12} {"Category":<18} {"Description":<30} {"Amount (₹)":>12}')
    print("-" * 88)
    for expense in expenses:
        description = expense["description"][:28]
        category = expense["category"][:16]
        print(
            f'{expense["expense_id"]:<5} {expense["date"]:<12} '
            f'{category:<18} {description:<30} {expense["amount"]:>12.2f}'
        )
    print("-" * 88)


def add_expense(expenses):
    print("\n--- Add Expense ---")
    date = read_date()
    while True:
        category = input("Enter category (e.g., Food, Travel, Education): ").strip()
        if category:
            break
        print("Category cannot be empty.")

    description = input("Enter description: ").strip()
    if not description:
        description = "No description"

    amount = read_amount()
    expense = {
        "expense_id": next_id(expenses),
        "date": date,
        "category": category.title(),
        "description": description,
        "amount": amount,
    }
    expenses.append(expense)
    if save_expenses(expenses):
        print(f'Expense added successfully! Your expense ID is {expense["expense_id"]}.')


def view_expenses(expenses):
    print("\n--- All Expenses ---")
    print_expense_table(sorted(expenses, key=lambda item: (item["date"], item["expense_id"])))


def search_expenses(expenses):
    print("\n--- Search Expenses ---")
    category = input("Enter category to search: ").strip().casefold()
    if not category:
        print("Search category cannot be empty.")
        return
    matches = [item for item in expenses if category in item["category"].casefold()]
    print_expense_table(matches)
    if matches:
        print(f"Total for matching expenses: ₹{sum(item['amount'] for item in matches):.2f}")


def update_expense(expenses):
    print("\n--- Update Expense ---")
    try:
        expense_id = int(input("Enter expense ID to update: ").strip())
    except ValueError:
        print("Please enter a valid numeric ID.")
        return

    expense = find_by_id(expenses, expense_id)
    if not expense:
        print("Expense ID not found.")
        return

    print("Press Enter to keep the current value.")
    new_date = input(f'Date [{expense["date"]}] (YYYY-MM-DD): ').strip()
    if new_date:
        try:
            expense["date"] = datetime.strptime(new_date, "%Y-%m-%d").strftime("%Y-%m-%d")
        except ValueError:
            print("Invalid date. Update cancelled.")
            return

    new_category = input(f'Category [{expense["category"]}]: ').strip()
    if new_category:
        expense["category"] = new_category.title()

    new_description = input(f'Description [{expense["description"]}]: ').strip()
    if new_description:
        expense["description"] = new_description

    new_amount = input(f'Amount (₹) [{expense["amount"]:.2f}]: ').strip()
    if new_amount:
        try:
            amount = float(new_amount.replace(",", ""))
            if amount <= 0:
                print("Amount must be greater than zero. Update cancelled.")
                return
            expense["amount"] = round(amount, 2)
        except ValueError:
            print("Invalid amount. Update cancelled.")
            return

    if save_expenses(expenses):
        print("Expense updated successfully!")


def delete_expense(expenses):
    print("\n--- Delete Expense ---")
    try:
        expense_id = int(input("Enter expense ID to delete: ").strip())
    except ValueError:
        print("Please enter a valid numeric ID.")
        return

    expense = find_by_id(expenses, expense_id)
    if not expense:
        print("Expense ID not found.")
        return

    print(f'You selected: {expense["category"]} - {expense["description"]} - ₹{expense["amount"]:.2f}')
    confirm = input("Are you sure you want to delete it? (y/n): ").strip().lower()
    if confirm == "y":
        expenses.remove(expense)
        if save_expenses(expenses):
            print("Expense deleted successfully!")
    else:
        print("Delete cancelled.")


def show_summary(expenses):
    print("\n--- Expense Summary ---")
    if not expenses:
        print("No expenses recorded yet.")
        return

    total = sum(item["amount"] for item in expenses)
    print(f"Number of expenses: {len(expenses)}")
    print(f"Total expenses: ₹{total:.2f}")
    print(f"Average expense: ₹{total / len(expenses):.2f}")

    totals_by_category = {}
    for item in expenses:
        totals_by_category[item["category"]] = (
            totals_by_category.get(item["category"], 0) + item["amount"]
        )

    print("\nCategory-wise totals:")
    for category, amount in sorted(totals_by_category.items()):
        print(f"  {category:<20} ₹{amount:.2f}")


def main():
    expenses = load_expenses()
    print("=" * 46)
    print("      EXPENSE TRACKER MANAGEMENT SYSTEM")
    print("=" * 46)
    print(f"Loaded {len(expenses)} saved expense(s).")

    while True:
        print("\nMAIN MENU")
        print("1. Add Expense")
        print("2. View All Expenses")
        print("3. Search by Category")
        print("4. Update Expense")
        print("5. Delete Expense")
        print("6. Show Expense Summary")
        print("7. Exit")

        choice = input("Enter your choice (1-7): ").strip()

        if choice == "1":
            add_expense(expenses)
        elif choice == "2":
            view_expenses(expenses)
        elif choice == "3":
            search_expenses(expenses)
        elif choice == "4":
            update_expense(expenses)
        elif choice == "5":
            delete_expense(expenses)
        elif choice == "6":
            show_summary(expenses)
        elif choice == "7":
            print("Thank you for using Expense Tracker. Goodbye!")
            break
        else:
            print("Invalid choice. Please enter a number from 1 to 7.")


if __name__ == "__main__":
    main()
